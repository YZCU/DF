function pre_rslt=track1_pre(pre_point,frame,h)

frames=frame-h+1;
x=pre_point((1:frames),1);
y=pre_point((1:frames),2);
if(frames<100)
    m=frames;
else
    m=100;
end
n=300;
len1=(1:m)';
px=polyfit(len1,x((end-m+1:end),:),2);
py=polyfit(len1,y((end-m+1:end),:),2);
new_line=(1:m+n)';
pr_px=polyval(px,new_line);
pr_py=polyval(py,new_line);
all_fin=[pr_px,pr_py];
pre_rslt=all_fin((end-n+1:end),:);
pre_rslt=pre_rslt(h,:);
end