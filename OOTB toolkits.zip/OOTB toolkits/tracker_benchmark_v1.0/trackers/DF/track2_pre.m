function pre_rslt=track2_pre(pre_point,frame,h)
x=pre_point((1:frame),1);
y=pre_point((1:frame),2);
if frame<=20
    m=frame;
else
    m=20;
end
n=2;
len1=(1:m)';
px=polyfit(len1,x((end-m+1:end),:),2);
py=polyfit(len1,y((end-m+1:end),:),2);
new_line=(1:m+n)';
pr_px=polyval(px,new_line);
pr_py=polyval(py,new_line);
all_fin=[pr_px,pr_py];
pre_rslt=all_fin((end-n+1:end),:);
pre_rslt=pre_rslt(1,:);
end