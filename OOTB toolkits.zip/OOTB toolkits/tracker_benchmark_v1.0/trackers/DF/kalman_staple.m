function kalman_Xn_result=kalman_staple(zhaungtai_pv)
a=zhaungtai_pv(:,:);
b=a';
ai=b(2,:);
aii=b(3,:);
b(2,:)=aii;
b(3,:)=ai;
T=1;
N=size(a,1);
X=zeros(4,N);
G=zeros(4,N);
for i=20:N
    Vx=(b(1,i)-b(1,i-19))/19;
    Vy=(b(3,i)-b(3,i-19))/19;
    
    b(2,i)=Vx;
    b(4,i)=Vy;
    V_x=(b(1,20)-b(1,1))/19;
    V_y=(b(3,20)-b(3,1))/19;
    b(2,1)=V_x;
    b(4,1)=V_y;
    X(:,1)=[b(1,1),V_x,b(3,1),V_y];
    Z=zeros(2,N);
    Z(:,1)=[X(1,1),X(3,1)];
    Q=diag([0.05,0,0.05,0]) ;
    R=[1,0;0,1];
    F=[1,T,0,0;
        0,1,0,0;
        0,0,1,T;
        0,0,0,1];
    H=[1,0,0,0;
        0,0,1,0];
    for t=2:N
        Z(:,t)=H*b(:,t)+sqrtm(R)*randn(2,1);
    end
    Xkf=zeros(4,N);
    Xkf(:,1)=b(:,1);
    P0=eye(4);
    for i=2:N
        Xn=F*Xkf(:,i-1);
        P1=F*P0*F'+Q;
        K=P1*H'*inv(H*P1*H'+R);
        Xkf(:,i)=Xn+K*(Z(:,i)-H*Xn);
        P0=(eye(4)-K*H)*P1;
    end
    kalman_Xn_result=[Xn(1,1),Xn(3,1)];
end