function qw1_runTracker()
start_frame=1;
sequence='D:\ImageData\Toy';
params = readParams('params.txt');
sequence_path = [sequence,'/'];
img_path = [sequence_path 'img/'];
text_files = dir([sequence_path '*_frames.txt']);
f = fopen([sequence_path text_files(1).name]);
frames = textscan(f, '%f,%f');
if exist('start_frame')
    frames{1} = start_frame;
else
    frames{1} = 1;
end
fclose(f);
params.bb_VOT = csvread([sequence_path 'groundtruth_rect.txt']);
region = params.bb_VOT(frames{1},:);
dir_content = dir([sequence_path 'img/']);
n_imgs = length(dir_content) - 2;
img_files = cell(n_imgs, 1);
for ii = 1:n_imgs
    img_files{ii} = dir_content(ii+2).name;
end
img_files(1:start_frame-1)=[];
im = imread([img_path img_files{1}]);
if(size(im,3)==1)
    params.grayscale_sequence = true;
end

params.img_files = img_files;
params.img_path = img_path;
if(numel(region)==8)
    [cx, cy, w, h] = getAxisAlignedBB(region);
else
    x = region(1);
    y = region(2);
    w = region(3);
    h = region(4);
    cx = x+w/2;
    cy = y+h/2;
end
params.init_pos = [cy cx];
params.target_sz = round([h w]);
[params, bg_area, fg_area, area_resize_factor] = initializeAllAreas(im, params);
if params.visualization
    params.videoPlayer = vision.VideoPlayer('Position', [100 100 [size(im,2), size(im,1)]+30]);
end
params.fout = -1;
trackerMain(params, im, bg_area, fg_area, area_resize_factor);
fclose('all');
end
