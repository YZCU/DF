function [results] = trackerMain(p, im, bg_area, fg_area, area_resize_factor,startframe, sai)
pos = p.init_pos;
target_sz = p.target_sz;
num_frames = numel(p.img_files);
padding = p.padding;
learning_rate = p.learning_rate;
compression_learning_rate = p.compression_learning_rate;
non_compressed_features = p.non_compressed_features;
compressed_features = p.compressed_features;
num_compressed_dim = p.num_compressed_dim;
temp = load('w2crs');
w2c = temp.w2crs;
use_dimensionality_reduction = ~isempty(compressed_features);
sz = floor(target_sz * (1 + padding));
projection_matrix = [];
h=0;
up=1;
q=0;
patch_padded = getSubwindow(im, pos, p.norm_bg_area, bg_area);
OTB_rect_positions = zeros(num_frames, 4);
new_pwp_model = true;
[bg_hist, fg_hist] = updateHistModel(new_pwp_model, patch_padded, bg_area, fg_area, target_sz, p.norm_bg_area, p.n_bins, p.grayscale_sequence);
new_pwp_model = false;
if isToolboxAvailable('Signal Processing Toolbox')
    hann_window = single(hann(p.cf_response_size(1)) * hann(p.cf_response_size(2))');
else
    hann_window = single(myHann(p.cf_response_size(1)) * myHann(p.cf_response_size(2))');%p.cf_response_size��С�ĺ�����
end
% gaussian-shaped desired response, centred in (1,1)
% bandwidth proportional to target size
output_sigma = sqrt(prod(p.norm_target_sz)) * p.output_sigma_factor / p.hog_cell_size;
y = gaussianResponse(p.cf_response_size, output_sigma);
yf = fft2(y);
t_imread = 0;
response_max=zeros(num_frames, 1);
response_pw=zeros(num_frames, 1);
response_ho=zeros(num_frames, 1);
response_colorname=zeros(num_frames, 1);
response_APCE=zeros(num_frames, 1);
response_TCMI=zeros(num_frames, 1);
response_psr=zeros(num_frames, 1);
response_vary_APCE=zeros(num_frames, 1);
response_hog_psr=zeros(num_frames, 1);
response_cn_psr=zeros(num_frames, 1);
response_merg_psr=zeros(num_frames, 1);
cn_bili_all=zeros(num_frames, 1);
response_pwb_psr=zeros(num_frames, 1);
K_hog=zeros(num_frames, 1);
K_cn=zeros(num_frames, 1);
K_cn_bili=zeros(num_frames, 1);
learn_cn=zeros(num_frames, 1);
learn_hog=zeros(num_frames, 1);
tic;
for frame = startframe:num_frames
    if frame==startframe, rect_position = [pos([2,1]) - target_sz([2,1])/2, target_sz([2,1])]; end
    OTB_rect_positions(frame,:) = rect_position;
    response_max(1)=1;
    if frame > startframe
        tic_imread = tic;
        im = imread([p.img_path p.img_files{frame}]);
        t_imread = t_imread + toc(tic_imread);
        im_patch_cf = getSubwindow(im, pos, p.norm_bg_area, bg_area);
        [xo_npca, xo_pca] = get_subwindow(im, pos, p.cf_response_size, bg_area, non_compressed_features, compressed_features, w2c);
        xt = feature_projection(xo_npca, xo_pca, projection_matrix, hann_window);
        xt_windowed = bsxfun(@times, hann_window, xt);
        xtf = fft2(xt_windowed);
        if p.den_per_channel
            hf = cn_hf_num ./ (cn_hf_den + p.lambda);
        else
            hf = bsxfun(@rdivide, cn_hf_num, sum(cn_hf_den, 3)+p.lambda);
        end
        
        response_CN = ensure_real(ifft2(sum(conj(hf) .* xtf, 3)));
        response_CN = cropFilterResponse(response_CN, ...
            floor_odd(p.norm_delta_area / p.hog_cell_size));
        if p.hog_cell_size > 1
            response_cn = mexResize(response_CN, p.norm_delta_area,'auto');
        end
        pwp_search_area = round(p.norm_pwp_search_area / area_resize_factor);
        % extract patch of size pwp_search_area and resize to norm_pwp_search_area
        im_patch_pwp = getSubwindow(im, pos, p.norm_pwp_search_area, pwp_search_area);
        % compute feature map
        xt = getFeatureMap(im_patch_cf, p.feature_type, p.cf_response_size, p.hog_cell_size);
        % apply Hann window
        xt_windowed = bsxfun(@times, hann_window, xt);
        % compute FFT
        xtf = fft2(xt_windowed);
        % Correlation between filter and test patch gives the response
        % Solve diagonal system per pixel.
        if p.den_per_channel
            hf = hf_num ./ (hf_den + p.lambda);
        else
            hf = bsxfun(@rdivide, hf_num, sum(hf_den, 3)+p.lambda);
        end
        
        response_hog = ensure_real(ifft2(sum(conj(hf) .* xtf, 3)));
        % Crop square search region (in feature pixels).
        response_hog = cropFilterResponse(response_hog, ...
            floor_odd(p.norm_delta_area / p.hog_cell_size));
        if p.hog_cell_size > 1
            % Scale up to match center likelihood resolution.
            response_hog = mexResize(response_hog, p.norm_delta_area,'auto');
        end
        
        [likelihood_map] = getColourMap(im_patch_pwp, bg_hist, fg_hist, p.n_bins, p.grayscale_sequence);
        % (TODO) in theory it should be at 0.5 (unseen colors shoud have max entropy)
        likelihood_map(isnan(likelihood_map)) = 0;
        % each pixel of response_pwp loosely represents the likelihood that
        % the target (of size norm_target_sz) is centred on it
        response_pwp = getCenterLikelihood(likelihood_map, p.norm_target_sz);
        u=mean(response_hog(:));
        n=size(response_hog,1)*size(response_hog,2);
        st = sqrt(sum((response_hog(:)-u).^2)/(size(response_hog,1)*size(response_hog,2))) ;
        dem=(n-1)*(n-2)*(n-3)*st.^4;
        num=n*(n+1)*sum((response_hog(:)-u).^4)-3*sum((response_hog(:)-u).^2)^2*(n-1);
        K_hog(frame)=num/dem-3;
        u=mean(response_cn(:));
        n=size(response_cn,1)*size(response_cn,2);
        st = sqrt(sum((response_cn(:)-u).^2)/(size(response_cn,1)*size(response_cn,2))) ;
        dem=(n-1)*(n-2)*(n-3)*st.^4;
        num=n*(n+1)*sum((response_cn(:)-u).^4)-3*sum((response_cn(:)-u).^2)^2*(n-1);
        K_cn(frame)=num/dem-3;
        K_cn_bili(frame)=abs(K_cn(frame))/(abs(K_cn(frame))+abs(K_hog(frame)));
        if K_cn_bili(frame) > 0.2
            K_cn_bili(frame) = 0.2;
        end
        response_hog_cn = mergeResponses(response_hog, response_cn, K_cn_bili(frame), p.merge_method);
        response = mergeResponses(response_hog_cn, response_pwp, p.merge_factor, p.merge_method);
        [row, col] = find(response == max(response(:)), 1);
        center = (1+p.norm_delta_area) / 2;
        pos = pos + ([row, col] - center) / area_resize_factor;
        rect_position = [pos([2,1]) - target_sz([2,1])/2, target_sz([2,1])];
        if frame > 30
            if(K_hog(frame)> sai)
                h=0;
                up=1;
                OTB_rect_positions(frame,:) = rect_position;
                pos = rect_position([2,1])+ target_sz([1,2])/2;
            elseif (K_hog(frame) <= sai)
                up=0;
                h=h+1;
                q=q+1;
                if ( q<7 )
                    curve_rate = tqulv(OTB_rect_positions,frame);
                end
                if( 2 < curve_rate) && ( curve_rate < 15 )
                    kalman_Xn_result = kalman_staple(OTB_rect_positions((1:frame),:));
                    predict_pos = kalman_Xn_result;
                else
                    pre_rslt= track1_pre (OTB_rect_positions,frame,h);
                    predict_pos = pre_rslt;
                end
                rect_position(1,(1:2)) = predict_pos;
                pos = rect_position([2,1]) + target_sz([1,2])/2;
                OTB_rect_positions(frame,:) = rect_position;
            end
        end
    end
    if(up == 1)
        [xo_npca, xo_pca] = get_subwindow(im, pos, p.cf_response_size, bg_area, non_compressed_features, compressed_features, w2c);
        if frame == 1
            % initialize the appearance
            z_npca = xo_npca;
            z_pca = xo_pca;
            % set number of compressed dimensions to maximum if too many
            num_compressed_dim = min(num_compressed_dim, size(xo_pca, 2));
        else
            % update the appearance
            z_npca = (1 - learning_rate) * z_npca + learning_rate * xo_npca;
            z_pca = (1 - learning_rate) * z_pca + learning_rate * xo_pca;
        end
        % if dimensionality reduction is used: update the projection matrix
        if use_dimensionality_reduction
            % compute the mean appearance
            data_mean = mean(z_pca, 1);
            
            % substract the mean from the appearance to get the data matrix
            data_matrix = bsxfun(@minus, z_pca, data_mean);
            
            % calculate the covariance matrix
            cov_matrix = 1/(prod(sz) - 1) * (data_matrix' * data_matrix);
            
            % calculate the principal components (pca_basis) and corresponding variances
            if frame == 1
                [pca_basis, pca_variances, ~] = svd(cov_matrix);
            else
                [pca_basis, pca_variances, ~] = svd((1 - compression_learning_rate) * old_cov_matrix + compression_learning_rate * cov_matrix);
            end
            
            % calculate the projection matrix as the first principal
            % components and extract their corresponding variances
            projection_matrix = pca_basis(:, 1:num_compressed_dim);
            projection_variances = pca_variances(1:num_compressed_dim, 1:num_compressed_dim);
            
            if frame == 1
                % initialize the old covariance matrix using the computed
                % projection matrix and variances
                old_cov_matrix = projection_matrix * projection_variances * projection_matrix';
            else
                % update the old covariance matrix using the computed
                % projection matrix and variances
                old_cov_matrix = (1 - compression_learning_rate) * old_cov_matrix + compression_learning_rate * (projection_matrix * projection_variances * projection_matrix');
            end
        end
        % project the features of the new appearance example using the new
        % projection matrix
        x = feature_projection(xo_npca, xo_pca, projection_matrix, hann_window);
        
        % apply Hann window
        xt = bsxfun(@times, hann_window, x);
        % compute FFT
        xtf = fft2(xt);
        % FILTER UPDATE
        % Compute expectations over circular shifts,
        % therefore divide by number of pixels.
        cn_new_hf_num = bsxfun(@times, conj(yf), xtf) / prod(p.cf_response_size);
        cn_new_hf_den = (conj(xtf) .* xtf) / prod(p.cf_response_size);
        if frame == startframe
            % first frame, train with a single image
            cn_hf_den = cn_new_hf_den;
            cn_hf_num = cn_new_hf_num;
        else
            % subsequent frames, update the model by linear interpolation
            cn_hf_den = (1 - p.learning_rate) * cn_hf_den + p.learning_rate * cn_new_hf_den; % ���޸ģ�����ѧϰ��learning_rate_cf���Ը�Ϊcn ��ѧϰ��
            cn_hf_num = (1 - p.learning_rate) * cn_hf_num + p.learning_rate * cn_new_hf_num;
        end
        % extract patch of size bg_area and resize to norm_bg_area
        im_patch_bg = getSubwindow(im, pos, p.norm_bg_area, bg_area);
        % compute feature map, of cf_response_size
        xt = getFeatureMap(im_patch_bg, p.feature_type, p.cf_response_size, p.hog_cell_size);
        % apply Hann window
        xt = bsxfun(@times, hann_window, xt);
        % compute FFT
        xtf = fft2(xt);
        
        % Compute expectations over circular shifts,
        % therefore divide by number of pixels.
        new_hf_num = bsxfun(@times, conj(yf), xtf) / prod(p.cf_response_size);
        new_hf_den = (conj(xtf) .* xtf) / prod(p.cf_response_size);
        if frame == startframe
            % first frame, train with a single image
            hf_den = new_hf_den;
            hf_num = new_hf_num;
        else
            % subsequent frames, update the model by linear interpolation
            hf_den = (1 - p.learning_rate_cf) * hf_den + p.learning_rate_cf * new_hf_den;
            hf_num = (1 - p.learning_rate_cf) * hf_num + p.learning_rate_cf * new_hf_num;
            % BG/FG MODEL UPDATE
            [bg_hist, fg_hist] = updateHistModel(new_pwp_model, im_patch_bg, bg_area, fg_area, target_sz, p.norm_bg_area, p.n_bins, p.grayscale_sequence, bg_hist, fg_hist, p.learning_rate_pwp);
        end
    end
    % VISUALIZATION
    if p.visualization == 1
        if 0
            step(p.videoPlayer, im);
        else
            if frame == startframe  %first frame, create GUI
                figure
                im_handle = imshow(im);
                title('abc');
                rectt_handle = rectangle('Position',rect_position, 'EdgeColor','r','LineWidth',0.1);
                tex_handle = text(11, 22, strcat('frame:',num2str(frame)), 'Color','y', 'FontWeight','bold', 'FontSize',15);
                hold on;
                pos_handle = plot(pos(2),pos(1),' ','MarkerSize',1);
                drawnow;
            else
                try  % subsequent frames, update GUI
                    set(im_handle, 'CData', im)
                    set(rectt_handle, 'Position', rect_position)
                    set(tex_handle, 'string', strcat('frame:',num2str(frame)))
                    hold on
                    set(pos_handle,'XData',pos(2),'YData',pos(1),'MarkerSize',8)
                    drawnow;
                catch  % #ok, user has closed the window
                    warning('close');
                    return
                end
            end
        end
    end
end
elapsed_time = toc;
results.type = 'rect';
results.res = OTB_rect_positions;
results.len = num_frames;
results.fps = num_frames/(elapsed_time );
results.times = (elapsed_time - t_imread);
fprintf('rate:%f',results.fps);
end
% Reimplementation of Hann window (in case signal processing toolbox is missing)
function H = myHann(X)
H = .5*(1 - cos(2*pi*(0:X-1)'/(X-1)));
end

% We want odd regions so that the central pixel can be exact
function y = floor_odd(x)
y = 2*floor((x-1) / 2) + 1;
end

function y = ensure_real(x)
assert(norm(imag(x(:))) <= 1e-5 * norm(real(x(:))));
y = real(x);
end