function last_qulv=tqulv(pre_point,frame)
xx=pre_point((1:frame),1);
yy=pre_point((1:frame),2);
D=polyfit(xx,yy,4);
M=polyval(D,xx);
kappa_arr = [];
norm_arr = [];
n=10;
for num = n+1:1:(length(xx)-(n+1))
    x = xx(num-n:n:num+n);
    y = M(num-n:n:num+n);
    [kappa,norm_l] = PJcurvature(x,y);
    kappa_arr = [kappa_arr;kappa];
    norm_arr = [norm_arr;norm_l];
end
a=kappa_arr.* norm_arr(:,1);
b=kappa_arr.* norm_arr(:,2);
c=(a.^2+b.^2).^0.5;
last_qulv=10^4*c(end);
end