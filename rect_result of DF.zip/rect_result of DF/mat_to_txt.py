import os
import scipy.io
import numpy as np
src_dir = './original'
dst_dir = './obtained'
os.makedirs(dst_dir, exist_ok=True)
for filename in os.listdir(src_dir):
    if filename.endswith('.mat'):
        mat_path = os.path.join(src_dir, filename)
        data = scipy.io.loadmat(mat_path)
        struct = data[next(k for k in data if not k.startswith('__'))]
        res = struct['res'][0, 0]
        txt_filename = os.path.splitext(filename)[0] + '.txt'
        txt_path = os.path.join(dst_dir, txt_filename)
        np.savetxt(txt_path, res, fmt='%.6f')
